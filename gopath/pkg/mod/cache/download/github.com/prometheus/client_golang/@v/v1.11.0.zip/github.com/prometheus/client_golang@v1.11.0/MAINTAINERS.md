* Bartłomiej Płotka <bwplotka@gmail.com> @bwplotka
* Kemal Akkoyun <kakkoyun@gmail.com> @kakkoyun
