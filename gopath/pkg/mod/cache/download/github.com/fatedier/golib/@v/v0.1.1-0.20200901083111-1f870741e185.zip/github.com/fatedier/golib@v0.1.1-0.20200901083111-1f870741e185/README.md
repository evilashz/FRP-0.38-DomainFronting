# golib

[![Build Status](https://travis-ci.org/fatedier/golib.svg)](https://travis-ci.org/fatedier/golib)

Common go packages.
